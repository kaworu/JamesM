# Roll your own toy UNIX-clone OS

I'm just following http://www.jamesmolloy.co.uk/tutorial_html/.

The code should run fine under Ubuntu 13.04 though, I've had to hack a bit the
tutorial (mainly the bochs config).
